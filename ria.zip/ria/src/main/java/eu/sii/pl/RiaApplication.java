package eu.sii.pl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiaApplication.class, args);
	}
}
